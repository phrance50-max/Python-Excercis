#Topics: Variables, Lists, Tuples, & Built-in Functions*

#Section 1: Lists (Methods & Slicing)*

# Question 1
market_list = ["Yam", "Tomato", "Onion"]
market_list.append("Fish")
print(market_list)

# Question 2
Given_grades = [80, 90, 70]
Given_grades.insert(1, 85)
print(Given_grades)

# Questionb3
gadgets = ["Laptop", "Phone", "Tablet", "Phone"]
gadgets.remove("Phone")
print(gadgets)

# Question 4
colors = ["Red", "Blue", "Green"]
colors.clear()
print(colors)

# Question 5
votes = ["Yes", "No", "Yes", "Yes", "No"]
yes_count = votes.count("Yes")
print(yes_count)

# Question 6
alphabets = ["a", "b", "c", "d", "e", "f"]
print(alphabets[2:5])

# Question 7
students = ["Kofi", "Ama", "Yaw"]
students.reverse()
print(students)

# Question 8
list_a = [1, 2]
list_b = [3, 4]
list_a.extend(list_b)
print(list_a)


# Question 9
Cities = ["Accra", "Kumasi", "Tamale"]
removed_city = Cities.pop(2)
print(Cities)

# Question 10
items = ["Pen", "Ruler", "Eraser"]
items.index("Ruler")
print(items)


# Section 2: Tuples & Data Types
# Question 1
student_info = ("Araba", 20)
student_info[1] = 21
print(student_info)                 #Tuple is immutable (cannot be changed)


# Question 2
tup = (1, 2, 3)
temp = list(tup)
temp.append(4)
tup = tuple(temp)
print(tup)

# Question 3
Data = (10, 20, 10, 30, 10)
yes_count = Data.count(10)
print(yes_count)

# Question 4
colors = ("Red", "Blue", "Green")
position = colors.index("Blue")
print(position)

# Question 5
coords = (5.6, -0.1)
lat, lon = coords

print(lat)
print(lon)

# Question 6
nest = (5, 10)
print(len(nest))

# Question 7
Numbers = (10, 20, 30, 40, 50)
print(Numbers[-2:])

# Question 8
my_list = [1, 2]
my_list.extend((3, 4))
print(my_list)

# Question 9
my_tup = ()
del my_tup

# Question 10
x = (5)
y = (5,)

print(type(x)) # int
print(type(y) ) # tuple